<?php

include('./function.php');

$posts = [
    ["title" => "post one", "slug" => "slug one", "img" => "img/pic1.jpg"],
    ["title" => "post two", "slug" => "slug two", "img" => "img/pic2.jpg"],
    ["title" => "post tree", "slug" => "slug tree", "img" => "img/pic3.jpg"],
    ["title" => "post four", "slug" => "slug four", "img" => "img/pic4.jpg"]
];

$posts_tmp = get_template("./tamplates/elements/post_list.php", ["posts" => $posts]);

$elements_tmp = [
    "header" => get_template("./tamplates/elements/header.php"),
    "posts" => $posts,
    "gallery" => get_template("./tamplates/elements/gallery.php"),
    "features" => get_template("./tamplates/elements/features.php"),
    "contact_form" => get_template("./tamplates/elements/contact_forms.php"),
    "footer" => get_template("./tamplates/elements/footer.php"),
    "script" => get_template("./tamplates/elements/script.php")
];

$page_tmp = get_template("./tamplates/pages/HOME.php", $elements);



$layout_tmp = get_template("./tamplates/layouts/main.php", ["page" => $page]);

echo $layout_tmp;