<?php

echo $header;

echo $posts;

echo $gallery;

echo $features;

echo $contact_forms;

echo $footer;

echo $script;